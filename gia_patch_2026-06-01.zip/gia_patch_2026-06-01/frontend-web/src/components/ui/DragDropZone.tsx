import React, { useCallback, useState } from 'react';
import { Upload, File, X } from 'lucide-react';

interface DragDropZoneProps {
  onFilesDrop: (files: File[]) => void;
  accept?: string;
  multiple?: boolean;
  maxSizeMB?: number;
  label?: string;
  existingFiles?: { name: string; size: number }[];
  onRemoveFile?: (index: number) => void;
}

export const DragDropZone: React.FC<DragDropZoneProps> = ({
  onFilesDrop,
  accept,
  multiple = true,
  maxSizeMB = 10,
  label = 'Перетащите файлы сюда или нажмите для выбора',
  existingFiles = [],
  onRemoveFile,
}) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const validateFiles = (files: FileList): File[] => {
    setError(null);
    const validFiles: File[] = [];
    const maxSize = maxSizeMB * 1024 * 1024;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (file.size > maxSize) {
        setError(`Файл "${file.name}" превышает ${maxSizeMB} МБ`);
        continue;
      }
      if (accept && !accept.split(',').some((type) => file.type.match(type.trim()) || file.name.endsWith(type.trim().replace('.', '')))) {
        setError(`Файл "${file.name}" имеет неподдерживаемый формат`);
        continue;
      }
      validFiles.push(file);
    }
    return validFiles;
  };

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setIsDragOver(false);
      const files = e.dataTransfer.files;
      if (files.length > 0) {
        const valid = validateFiles(files);
        if (valid.length > 0) onFilesDrop(valid);
      }
    },
    [onFilesDrop, accept, maxSizeMB]
  );

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const valid = validateFiles(files);
      if (valid.length > 0) onFilesDrop(valid);
    }
    e.target.value = '';
  };

  return (
    <div className="w-full">
      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        className={[
          'relative flex flex-col items-center justify-center rounded-xl border-2 border-dashed p-6 transition-colors cursor-pointer',
          isDragOver
            ? 'border-blue-500 bg-blue-50'
            : 'border-gray-300 bg-gray-50 hover:border-gray-400 hover:bg-gray-100',
        ].join(' ')}
      >
        <input
          type="file"
          accept={accept}
          multiple={multiple}
          onChange={handleInputChange}
          className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
        />
        <Upload
          size={32}
          className={isDragOver ? 'text-blue-500' : 'text-gray-400'}
        />
        <p className="mt-2 text-sm text-gray-600 text-center">{label}</p>
        <p className="mt-1 text-xs text-gray-400">
          Максимум {maxSizeMB} МБ {accept ? `(${accept})` : ''}
        </p>
      </div>

      {error && (
        <p className="mt-2 text-sm text-red-600">{error}</p>
      )}

      {existingFiles.length > 0 && (
        <div className="mt-3 space-y-2">
          {existingFiles.map((file, idx) => (
            <div
              key={idx}
              className="flex items-center gap-2 rounded-lg border bg-white p-2"
            >
              <File size={16} className="text-gray-400" />
              <span className="flex-1 text-sm text-gray-700 truncate">
                {file.name}
              </span>
              <span className="text-xs text-gray-400">
                {(file.size / 1024).toFixed(1)} КБ
              </span>
              {onRemoveFile && (
                <button
                  onClick={() => onRemoveFile(idx)}
                  className="rounded p-1 hover:bg-red-50 text-red-500"
                >
                  <X size={14} />
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
