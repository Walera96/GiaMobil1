import api from './axios';

export interface UploadFileDto {
  file: File;
  contextType?: 'ASSIGNMENT' | 'SUBMISSION' | 'PROTOCOL' | 'STATEMENT' | 'DRAFT' | 'SHARED_DRIVE';
  contextId?: string;
  visibility?: 'PRIVATE' | 'SHARED' | 'PUBLIC';
  allowedRoles?: string[];
  tags?: string[];
}

export interface FileDto {
  id: string;
  fileName: string;
  mimeType: string;
  fileSize: number;
  contextType: string;
  contextId?: string;
  uploadedBy: string;
  visibility: string;
  tags: string[];
  createdAt: string;
}

export const filesApi = {
  upload: async (dto: UploadFileDto): Promise<FileDto> => {
    const formData = new FormData();
    formData.append('file', dto.file);
    if (dto.contextType) formData.append('contextType', dto.contextType);
    if (dto.contextId) formData.append('contextId', dto.contextId);
    if (dto.visibility) formData.append('visibility', dto.visibility);
    if (dto.allowedRoles) formData.append('allowedRoles', JSON.stringify(dto.allowedRoles));
    if (dto.tags) formData.append('tags', JSON.stringify(dto.tags));

    const response = await api.post('/files/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return response.data;
  },

  download: async (fileId: string): Promise<Blob> => {
    const response = await api.get(`/files/${fileId}/download`, {
      responseType: 'blob',
    });
    return response.data;
  },

  list: async (contextType?: string, contextId?: string): Promise<FileDto[]> => {
    const params = new URLSearchParams();
    if (contextType) params.append('contextType', contextType);
    if (contextId) params.append('contextId', contextId);
    const response = await api.get(`/files?${params.toString()}`);
    return response.data;
  },

  delete: async (fileId: string): Promise<void> => {
    await api.delete(`/files/${fileId}`);
  },
};
