package com.spbutu.gia.files.web.controller;

import com.spbutu.gia.files.domain.entity.FileStorage;
import com.spbutu.gia.files.domain.repository.FileStorageRepository;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.List;
import java.util.UUID;

/**
 * Контроллер для работы с общим хранилищем файлов.
 */
@RestController
@RequestMapping("/api/files")
public class FileStorageController {

    private final FileStorageRepository fileStorageRepository;

    public FileStorageController(FileStorageRepository fileStorageRepository) {
        this.fileStorageRepository = fileStorageRepository;
    }

    /**
     * Загрузка файла.
     */
    @PostMapping("/upload")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<FileStorage> uploadFile(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "contextType", defaultValue = "SHARED_DRIVE") String contextType,
            @RequestParam(value = "contextId", required = false) String contextId,
            @RequestParam(value = "visibility", defaultValue = "PRIVATE") String visibility,
            @RequestParam(value = "allowedRoles", required = false) String allowedRoles,
            @RequestParam(value = "tags", required = false) String tags,
            Authentication authentication
    ) throws IOException, NoSuchAlgorithmException {

        String userId = authentication.getName();

        FileStorage storage = new FileStorage();
        storage.setFileName(file.getOriginalFilename());
        storage.setMimeType(file.getContentType() != null ? file.getContentType() : "application/octet-stream");
        storage.setFileSize(file.getSize());
        storage.setFileData(file.getBytes());
        storage.setContextType(contextType);
        storage.setContextId(contextId != null ? UUID.fromString(contextId) : null);
        storage.setUploadedBy(UUID.fromString(userId));
        storage.setVisibility(visibility);
        storage.setAllowedRoles(allowedRoles != null ? allowedRoles : "[]");
        storage.setTags(tags != null ? tags : "[]");
        storage.setChecksum(calculateChecksum(file.getBytes()));

        FileStorage saved = fileStorageRepository.save(storage);
        return ResponseEntity.ok(saved);
    }

    /**
     * Список файлов с фильтрацией.
     */
    @GetMapping
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<List<FileStorage>> listFiles(
            @RequestParam(value = "contextType", required = false) String contextType,
            @RequestParam(value = "contextId", required = false) String contextId
    ) {
        List<FileStorage> files;
        if (contextType != null && contextId != null) {
            files = fileStorageRepository.findByContextTypeAndContextId(
                    contextType, UUID.fromString(contextId));
        } else if (contextType != null) {
            files = fileStorageRepository.findByContextType(contextType);
        } else {
            files = fileStorageRepository.findAll();
        }
        return ResponseEntity.ok(files);
    }

    /**
     * Скачивание файла.
     */
    @GetMapping("/{id}/download")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Resource> downloadFile(
            @PathVariable UUID id,
            HttpServletRequest request
    ) {
        FileStorage file = fileStorageRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Файл не найден"));

        ByteArrayResource resource = new ByteArrayResource(file.getFileData());

        String contentType = file.getMimeType();
        if (contentType == null) {
            contentType = request.getServletContext().getMimeType(file.getFileName());
        }
        if (contentType == null) {
            contentType = "application/octet-stream";
        }

        String encodedFileName = encodeFileName(file.getFileName());

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename*=UTF-8''" + encodedFileName)
                .body(resource);
    }

    /**
     * Удаление файла.
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Void> deleteFile(@PathVariable UUID id) {
        fileStorageRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    private String calculateChecksum(byte[] data) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] digest = md.digest(data);
        return Base64.getEncoder().encodeToString(digest);
    }

    private String encodeFileName(String fileName) {
        return java.net.URLEncoder.encode(fileName, StandardCharsets.UTF_8)
                .replace("+", "%20");
    }
}
