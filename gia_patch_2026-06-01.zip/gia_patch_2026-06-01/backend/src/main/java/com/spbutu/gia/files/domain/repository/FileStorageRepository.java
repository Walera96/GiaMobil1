package com.spbutu.gia.files.domain.repository;

import com.spbutu.gia.files.domain.entity.FileStorage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface FileStorageRepository extends JpaRepository<FileStorage, UUID> {

    List<FileStorage> findByContextTypeAndContextId(String contextType, UUID contextId);

    List<FileStorage> findByContextType(String contextType);

    List<FileStorage> findByUploadedBy(UUID uploadedBy);

    List<FileStorage> findByVisibility(String visibility);
}
