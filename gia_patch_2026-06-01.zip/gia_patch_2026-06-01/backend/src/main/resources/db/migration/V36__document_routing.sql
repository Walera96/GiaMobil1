-- ============================================================
-- Миграция V36: Документооборот — маршрутизация документов
-- Позволяет пересылать документы между ролями и подразделениями
-- ============================================================

-- ============================================================
-- 1. Таблица маршрутов документов
-- ============================================================
CREATE TABLE IF NOT EXISTS document_route (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Ссылка на исходный документ (черновик или протокол)
    source_type VARCHAR(50) NOT NULL CHECK (source_type IN ('DRAFT', 'PROTOCOL', 'STATEMENT', 'ASSIGNMENT', 'GENERAL')),
    source_id UUID NOT NULL,
    
    -- Название и описание маршрута
    name VARCHAR(255) NOT NULL,
    description TEXT,
    
    -- Статус маршрута
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'COMPLETED', 'CANCELLED')),
    
    -- Кто инициировал
    initiated_by UUID NOT NULL REFERENCES app_user(id) ON DELETE SET NULL,
    
    -- Целевое подразделение / роль (кому направлено)
    target_department VARCHAR(100),
    target_role VARCHAR(30),
    target_user_id UUID REFERENCES app_user(id) ON DELETE SET NULL,
    
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP
);

CREATE INDEX idx_document_route_source ON document_route(source_type, source_id);
CREATE INDEX idx_document_route_status ON document_route(status);
CREATE INDEX idx_document_route_target ON document_route(target_department, target_role);

-- ============================================================
-- 2. Таблица этапов маршрута (кто, когда, что сделал)
-- ============================================================
CREATE TABLE IF NOT EXISTS document_route_step (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    route_id UUID NOT NULL REFERENCES document_route(id) ON DELETE CASCADE,
    
    -- Порядковый номер этапа
    step_number INT NOT NULL DEFAULT 1,
    
    -- Название этапа
    title VARCHAR(255) NOT NULL,
    
    -- Описание действия
    description TEXT,
    
    -- Исполнитель (роль или конкретный пользователь)
    performer_role VARCHAR(30),
    performer_user_id UUID REFERENCES app_user(id) ON DELETE SET NULL,
    
    -- Статус этапа
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'IN_PROGRESS', 'APPROVED', 'REJECTED', 'SKIPPED')),
    
    -- Действие, которое нужно выполнить
    action_required VARCHAR(100) NOT NULL DEFAULT 'REVIEW' CHECK (action_required IN ('REVIEW', 'SIGN', 'APPROVE', 'REJECT', 'FORWARD', 'ARCHIVE')),
    
    -- Комментарий исполнителя
    comment TEXT,
    
    -- Дедлайн
    deadline TIMESTAMP,
    
    -- Даты
    assigned_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP,
    
    -- К следующему этапу (при успешном выполнении)
    next_step_id UUID REFERENCES document_route_step(id) ON DELETE SET NULL
);

CREATE INDEX idx_route_step_route ON document_route_step(route_id);
CREATE INDEX idx_route_step_status ON document_route_step(status);

-- ============================================================
-- 3. Таблица вложений к маршруту (файлы, пересылаемые вместе с документом)
-- ============================================================
CREATE TABLE IF NOT EXISTS document_route_attachment (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    route_id UUID NOT NULL REFERENCES document_route(id) ON DELETE CASCADE,
    file_id UUID NOT NULL REFERENCES file_storage(id) ON DELETE CASCADE,
    added_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_route_attachment_route ON document_route_attachment(route_id);

-- ============================================================
-- 4. Шаблоны маршрутов (предустановленные)
-- ============================================================
CREATE TABLE IF NOT EXISTS document_route_template (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL UNIQUE,
    description TEXT,
    
    -- Шаги в формате JSON
    steps_config JSONB NOT NULL DEFAULT '[]',
    
    -- К какому типу документов применяется
    applicable_to VARCHAR(50) NOT NULL DEFAULT 'GENERAL',
    
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Предустановленные шаблоны маршрутов

-- Шаблон: Деканат → Секретарь ГЭК
INSERT INTO document_route_template (id, name, description, steps_config, applicable_to) VALUES
('rt111111-1111-1111-1111-111111111111', 
 'Деканат → ГЭК', 
 'Передача документов от деканата к секретарю ГЭК для формирования протоколов',
 '[
   {"step_number":1,"title":"Согласование в деканате","action_required":"APPROVE","performer_role":"DEAN"},
   {"step_number":2,"title":"Передача в ГЭК","action_required":"FORWARD","performer_role":"DEAN_SECRETARY"},
   {"step_number":3,"title":"Регистрация в ГЭК","action_required":"REVIEW","performer_role":"GEK_SECRETARY"}
 ]'::jsonb,
 'GENERAL'
)
ON CONFLICT DO NOTHING;

-- Шаблон: Кафедра → Деканат
INSERT INTO document_route_template (id, name, description, steps_config, applicable_to) VALUES
('rt222222-2222-2222-2222-222222222222',
 'Кафедра → Деканат',
 'Передача отчетов кафедры в деканат',
 '[
   {"step_number":1,"title":"Согласование зав. кафедрой","action_required":"APPROVE","performer_role":"DEPARTMENT_HEAD"},
   {"step_number":2,"title":"Передача в деканат","action_required":"FORWARD","performer_role":"DEPARTMENT_SECRETARY"},
   {"step_number":3,"title":"Регистрация в деканате","action_required":"REVIEW","performer_role":"DEAN_SECRETARY"}
 ]'::jsonb,
 'GENERAL'
)
ON CONFLICT DO NOTHING;

-- Шаблон: ГЭК → Бухгалтерия
INSERT INTO document_route_template (id, name, description, steps_config, applicable_to) VALUES
('rt333333-3333-3333-3333-333333333333',
 'ГЭК → Бухгалтерия',
 'Передача подписанных протоколов в бухгалтерию для начисления стипендии',
 '[
   {"step_number":1,"title":"Подписание председателем ГЭК","action_required":"SIGN","performer_role":"GEK_CHAIRMAN"},
   {"step_number":2,"title":"Передача в бухгалтерию","action_required":"FORWARD","performer_role":"GEK_SECRETARY"},
   {"step_number":3,"title":"Регистрация в бухгалтерии","action_required":"ARCHIVE","performer_role":"DEAN_SECRETARY"}
 ]'::jsonb,
 'PROTOCOL'
)
ON CONFLICT DO NOTHING;

-- Шаблон: Деканат → Администрация
INSERT INTO document_route_template (id, name, description, steps_config, applicable_to) VALUES
('rt444444-4444-4444-4444-444444444444',
 'Деканат → Администрация',
 'Передача приказов и распоряжений в администрацию вуза',
 '[
   {"step_number":1,"title":"Утверждение деканом","action_required":"APPROVE","performer_role":"DEAN"},
   {"step_number":2,"title":"Передача в администрацию","action_required":"FORWARD","performer_role":"DEAN_SECRETARY"},
   {"step_number":3,"title":"Регистрация администратором","action_required":"ARCHIVE","performer_role":"UNIVERSITY_ADMIN"}
 ]'::jsonb,
 'GENERAL'
)
ON CONFLICT DO NOTHING;

-- ============================================================
-- 5. Уведомления при движении документа
-- ============================================================

CREATE TABLE IF NOT EXISTS document_route_notification (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    route_id UUID NOT NULL REFERENCES document_route(id) ON DELETE CASCADE,
    step_id UUID REFERENCES document_route_step(id) ON DELETE SET NULL,
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    message TEXT NOT NULL,
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_route_notif_user ON document_route_notification(user_id, is_read);
