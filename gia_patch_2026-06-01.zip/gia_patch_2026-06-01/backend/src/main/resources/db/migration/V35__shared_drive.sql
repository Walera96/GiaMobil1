-- ============================================================
-- Миграция V35: Общий диск для хранения файлов
-- Таблица file_storage — единое хранилище вложений
-- ============================================================

CREATE TABLE IF NOT EXISTS file_storage (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Имя файла и MIME-тип
    file_name VARCHAR(255) NOT NULL,
    mime_type VARCHAR(100) NOT NULL DEFAULT 'application/octet-stream',
    
    -- Размер файла в байтах
    file_size BIGINT NOT NULL DEFAULT 0,
    
    -- Данные файла (байты) — храним в БД для небольших файлов (< 10 МБ)
    -- Для больших файлов можно использовать ссылку на внешнее хранилище
    file_data BYTEA,
    
    -- Ссылка на внешнее хранилище (S3, minio, файловая система)
    external_url VARCHAR(1000),
    
    -- Контекст: к чему прикреплён файл
    -- Возможные значения: ASSIGNMENT, SUBMISSION, PROTOCOL, STATEMENT, DRAFT, SHARED_DRIVE
    context_type VARCHAR(50) NOT NULL DEFAULT 'SHARED_DRIVE',
    context_id UUID,
    
    -- Кто загрузил
    uploaded_by UUID NOT NULL REFERENCES app_user(id) ON DELETE SET NULL,
    
    -- Доступ: PRIVATE (только загрузивший), SHARED (роли), PUBLIC (все)
    visibility VARCHAR(20) NOT NULL DEFAULT 'PRIVATE' CHECK (visibility IN ('PRIVATE', 'SHARED', 'PUBLIC')),
    
    -- Роли, которым доступен файл (если SHARED)
    allowed_roles JSONB DEFAULT '[]',
    
    -- Метки / теги для поиска
    tags JSONB DEFAULT '[]',
    
    -- Контрольная сумма MD5
    checksum VARCHAR(32),
    
    -- Даты
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Индексы для поиска
CREATE INDEX idx_file_storage_context ON file_storage(context_type, context_id);
CREATE INDEX idx_file_storage_uploaded_by ON file_storage(uploaded_by);
CREATE INDEX idx_file_storage_tags ON file_storage USING GIN (tags);
CREATE INDEX idx_file_storage_visibility ON file_storage(visibility);
CREATE INDEX idx_file_storage_created_at ON file_storage(created_at DESC);

-- ============================================================
-- Папки / директории в общем диске (логическая структура)
-- ============================================================

CREATE TABLE IF NOT EXISTS file_folder (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    parent_id UUID REFERENCES file_folder(id) ON DELETE CASCADE,
    created_by UUID NOT NULL REFERENCES app_user(id) ON DELETE SET NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_file_folder_parent ON file_folder(parent_id);

-- Связь файлов с папками (many-to-many, файл может быть в нескольких папках)
CREATE TABLE IF NOT EXISTS file_folder_item (
    folder_id UUID NOT NULL REFERENCES file_folder(id) ON DELETE CASCADE,
    file_id UUID NOT NULL REFERENCES file_storage(id) ON DELETE CASCADE,
    added_by UUID NOT NULL REFERENCES app_user(id) ON DELETE SET NULL,
    added_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (folder_id, file_id)
);

-- ============================================================
-- Встроенная папка "Общий диск" для каждого пользователя
-- ============================================================

-- Папки по умолчанию (создаются администратором)
INSERT INTO file_folder (id, name, parent_id, created_by) VALUES
('f0000000-0000-0000-0000-000000000001', 'Общий диск (деканат)', NULL, 'u0000000-0000-0000-0000-000000000001'),
('f0000000-0000-0000-0000-000000000002', 'Общий диск (кафедра)', NULL, 'u0000000-0000-0000-0000-000000000001'),
('f0000000-0000-0000-0000-000000000003', 'Общий диск (ГЭК)', NULL, 'u0000000-0000-0000-0000-000000000001'),
('f0000000-0000-0000-0000-000000000004', 'Общий диск (методист)', NULL, 'u0000000-0000-0000-0000-000000000001')
ON CONFLICT DO NOTHING;
