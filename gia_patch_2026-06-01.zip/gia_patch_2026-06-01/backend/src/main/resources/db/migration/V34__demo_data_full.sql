-- ============================================================
-- Миграция V34: Полноценные пробные данные для всех модулей
-- Тестовые учётные записи с паролями (bcrypt: "password")
-- ============================================================

-- Пароль "password" закодирован bcrypt → $2a$10$N9qo8uLOickgx2ZMRZoMy.MqrqQz0bIv.MWgW1u2Yw8z.IJ2u1v2a

-- ==========================================
-- 1. Направления
-- ==========================================
INSERT INTO direction (id, code, name) VALUES
('d1111111-1111-1111-1111-111111111111', '09.03.03', 'Прикладная информатика'),
('d2222222-2222-2222-2222-222222222222', '09.03.01', 'Информатика и вычислительная техника'),
('d3333333-3333-3333-3333-333333333333', '09.03.04', 'Программная инженерия')
ON CONFLICT DO NOTHING;

-- ==========================================
-- 2. Учебные группы
-- ==========================================
INSERT INTO study_group (id, name, direction_id, course) VALUES
('g1111111-1111-1111-1111-111111111111', 'ПИ-101', 'd1111111-1111-1111-1111-111111111111', 4),
('g2222222-2222-2222-2222-222222222222', 'ПИ-102', 'd1111111-1111-1111-1111-111111111111', 4),
('g3333333-3333-3333-3333-333333333333', 'ИВТ-201', 'd2222222-2222-2222-2222-222222222222', 3),
('g4444444-4444-4444-4444-444444444444', 'ПИН-301', 'd3333333-3333-3333-3333-333333333333', 2)
ON CONFLICT DO NOTHING;

-- ==========================================
-- 3. Тестовые пользователи (все роли)
-- ==========================================

-- Системный администратор
INSERT INTO app_user (id, username, password, email, full_name, primary_portal) VALUES
('u0000000-0000-0000-0000-000000000001', 'admin', '$2a$10$N9qo8uLOickgx2ZMRZoMy.MqrqQz0bIv.MWgW1u2Yw8z.IJ2u1v2a', 'admin@spbutu.ru', 'Администратор Системы', 'admin')
ON CONFLICT DO NOTHING;
INSERT INTO user_roles (user_id, role) VALUES ('u0000000-0000-0000-0000-000000000001', 'SYSTEM_ADMIN') ON CONFLICT DO NOTHING;

-- Университетский администратор
INSERT INTO app_user (id, username, password, email, full_name, primary_portal) VALUES
('u0000000-0000-0000-0000-000000000002', 'univ_admin', '$2a$10$N9qo8uLOickgx2ZMRZoMy.MqrqQz0bIv.MWgW1u2Yw8z.IJ2u1v2a', 'univ_admin@spbutu.ru', 'Иванова Мария Петровна', 'admin')
ON CONFLICT DO NOTHING;
INSERT INTO user_roles (user_id, role) VALUES ('u0000000-0000-0000-0000-000000000002', 'UNIVERSITY_ADMIN') ON CONFLICT DO NOTHING;

-- Декан
INSERT INTO app_user (id, username, password, email, full_name, primary_portal) VALUES
('u0000000-0000-0000-0000-000000000003', 'dean', '$2a$10$N9qo8uLOickgx2ZMRZoMy.MqrqQz0bIv.MWgW1u2Yw8z.IJ2u1v2a', 'dean@spbutu.ru', 'Петров Сергей Александрович', 'deanery')
ON CONFLICT DO NOTHING;
INSERT INTO user_roles (user_id, role) VALUES ('u0000000-0000-0000-0000-000000000003', 'DEAN') ON CONFLICT DO NOTHING;

-- Секретарь деканата
INSERT INTO app_user (id, username, password, email, full_name, primary_portal) VALUES
('u0000000-0000-0000-0000-000000000004', 'dean_sec', '$2a$10$N9qo8uLOickgx2ZMRZoMy.MqrqQz0bIv.MWgW1u2Yw8z.IJ2u1v2a', 'dean_sec@spbutu.ru', 'Сидорова Анна Владимировна', 'deanery')
ON CONFLICT DO NOTHING;
INSERT INTO user_roles (user_id, role) VALUES ('u0000000-0000-0000-0000-000000000004', 'DEAN_SECRETARY') ON CONFLICT DO NOTHING;

-- Заведующий кафедрой
INSERT INTO app_user (id, username, password, email, full_name, primary_portal) VALUES
('u0000000-0000-0000-0000-000000000005', 'dep_head', '$2a$10$N9qo8uLOickgx2ZMRZoMy.MqrqQz0bIv.MWgW1u2Yw8z.IJ2u1v2a', 'dep_head@spbutu.ru', 'Кузнецов Дмитрий Викторович', 'department')
ON CONFLICT DO NOTHING;
INSERT INTO user_roles (user_id, role) VALUES ('u0000000-0000-0000-0000-000000000005', 'DEPARTMENT_HEAD') ON CONFLICT DO NOTHING;

-- Секретарь кафедры
INSERT INTO app_user (id, username, password, email, full_name, primary_portal) VALUES
('u0000000-0000-0000-0000-000000000006', 'dep_sec', '$2a$10$N9qo8uLOickgx2ZMRZoMy.MqrqQz0bIv.MWgW1u2Yw8z.IJ2u1v2a', 'dep_sec@spbutu.ru', 'Волкова Елена Сергеевна', 'department')
ON CONFLICT DO NOTHING;
INSERT INTO user_roles (user_id, role) VALUES ('u0000000-0000-0000-0000-000000000006', 'DEPARTMENT_SECRETARY') ON CONFLICT DO NOTHING;

-- Руководитель ВКР (преподаватель)
INSERT INTO app_user (id, username, password, email, full_name, primary_portal) VALUES
('u0000000-0000-0000-0000-000000000007', 'supervisor', '$2a$10$N9qo8uLOickgx2ZMRZoMy.MqrqQz0bIv.MWgW1u2Yw8z.IJ2u1v2a', 'supervisor@spbutu.ru', 'Смирнов Алексей Павлович', 'teacher_portal')
ON CONFLICT DO NOTHING;
INSERT INTO user_roles (user_id, role) VALUES ('u0000000-0000-0000-0000-000000000007', 'SUPERVISOR') ON CONFLICT DO NOTHING;

-- Секретарь ГЭК
INSERT INTO app_user (id, username, password, email, full_name, primary_portal) VALUES
('u0000000-0000-0000-0000-000000000008', 'gek_sec', '$2a$10$N9qo8uLOickgx2ZMRZoMy.MqrqQz0bIv.MWgW1u2Yw8z.IJ2u1v2a', 'gek_sec@spbutu.ru', 'Новикова Татьяна Михайловна', 'gek')
ON CONFLICT DO NOTHING;
INSERT INTO user_roles (user_id, role) VALUES ('u0000000-0000-0000-0000-000000000008', 'GEK_SECRETARY') ON CONFLICT DO NOTHING;

-- Председатель ГЭК
INSERT INTO app_user (id, username, password, email, full_name, primary_portal) VALUES
('u0000000-0000-0000-0000-000000000009', 'gek_chair', '$2a$10$N9qo8uLOickgx2ZMRZoMy.MqrqQz0bIv.MWgW1u2Yw8z.IJ2u1v2a', 'gek_chair@spbutu.ru', 'Морозов Владимир Иванович', 'gek')
ON CONFLICT DO NOTHING;
INSERT INTO user_roles (user_id, role) VALUES ('u0000000-0000-0000-0000-000000000009', 'GEK_CHAIRMAN') ON CONFLICT DO NOTHING;

-- Член ГЭК
INSERT INTO app_user (id, username, password, email, full_name, primary_portal) VALUES
('u0000000-0000-0000-0000-000000000010', 'gek_member', '$2a$10$N9qo8uLOickgx2ZMRZoMy.MqrqQz0bIv.MWgW1u2Yw8z.IJ2u1v2a', 'gek_member@spbutu.ru', 'Лебедева Ольга Николаевна', 'gek')
ON CONFLICT DO NOTHING;
INSERT INTO user_roles (user_id, role) VALUES ('u0000000-0000-0000-0000-000000000010', 'GEK_MEMBER') ON CONFLICT DO NOTHING;

-- Методист
INSERT INTO app_user (id, username, password, email, full_name, primary_portal) VALUES
('u0000000-0000-0000-0000-000000000011', 'methodist', '$2a$10$N9qo8uLOickgx2ZMRZoMy.MqrqQz0bIv.MWgW1u2Yw8z.IJ2u1v2a', 'methodist@spbutu.ru', 'Попова Светлана Андреевна', 'methodist')
ON CONFLICT DO NOTHING;
INSERT INTO user_roles (user_id, role) VALUES ('u0000000-0000-0000-0000-000000000011', 'METHODIST') ON CONFLICT DO NOTHING;

-- Студенты
INSERT INTO app_user (id, username, password, email, full_name, primary_portal, study_group_id) VALUES
('u0000000-0000-0000-0000-000000000012', 'student1', '$2a$10$N9qo8uLOickgx2ZMRZoMy.MqrqQz0bIv.MWgW1u2Yw8z.IJ2u1v2a', 'student1@spbutu.ru', 'Андреев Павел Игоревич', 'student_portal', 'g1111111-1111-1111-1111-111111111111'),
('u0000000-0000-0000-0000-000000000013', 'student2', '$2a$10$N9qo8uLOickgx2ZMRZoMy.MqrqQz0bIv.MWgW1u2Yw8z.IJ2u1v2a', 'student2@spbutu.ru', 'Борисова Ксения Дмитриевна', 'student_portal', 'g1111111-1111-1111-1111-111111111111'),
('u0000000-0000-0000-0000-000000000014', 'student3', '$2a$10$N9qo8uLOickgx2ZMRZoMy.MqrqQz0bIv.MWgW1u2Yw8z.IJ2u1v2a', 'student3@spbutu.ru', 'Васильев Артём Сергеевич', 'student_portal', 'g2222222-2222-2222-2222-222222222222'),
('u0000000-0000-0000-0000-000000000015', 'student4', '$2a$10$N9qo8uLOickgx2ZMRZoMy.MqrqQz0bIv.MWgW1u2Yw8z.IJ2u1v2a', 'student4@spbutu.ru', 'Григорьева Мария Алексеевна', 'student_portal', 'g2222222-2222-2222-2222-222222222222')
ON CONFLICT DO NOTHING;

INSERT INTO user_roles (user_id, role) VALUES
('u0000000-0000-0000-0000-000000000012', 'STUDENT'),
('u0000000-0000-0000-0000-000000000013', 'STUDENT'),
('u0000000-0000-0000-0000-000000000014', 'STUDENT'),
('u0000000-0000-0000-0000-000000000015', 'STUDENT')
ON CONFLICT DO NOTHING;

-- ==========================================
-- 4. Студенты (связь с пользователями)
-- ==========================================
INSERT INTO student (id, user_id, last_name, first_name, middle_name, record_book_number, group_id) VALUES
('s1111111-1111-1111-1111-111111111111', 'u0000000-0000-0000-0000-000000000012', 'Андреев', 'Павел', 'Игоревич', '2021-00001', 'g1111111-1111-1111-1111-111111111111'),
('s2222222-2222-2222-2222-222222222222', 'u0000000-0000-0000-0000-000000000013', 'Борисова', 'Ксения', 'Дмитриевна', '2021-00002', 'g1111111-1111-1111-1111-111111111111'),
('s3333333-3333-3333-3333-333333333333', 'u0000000-0000-0000-0000-000000000014', 'Васильев', 'Артём', 'Сергеевич', '2021-00003', 'g2222222-2222-2222-2222-222222222222'),
('s4444444-4444-4444-4444-444444444444', 'u0000000-0000-0000-0000-000000000015', 'Григорьева', 'Мария', 'Алексеевна', '2021-00004', 'g2222222-2222-2222-2222-222222222222')
ON CONFLICT DO NOTHING;

-- ==========================================
-- 5. Преподаватели (для руководителей ВКР)
-- ==========================================
INSERT INTO teacher (id, first_name, last_name, middle_name, academic_title, department) VALUES
('t1111111-1111-1111-1111-111111111111', 'Алексей', 'Смирнов', 'Павлович', 'Доцент', 'Кафедра информационных систем'),
('t2222222-2222-2222-2222-222222222222', 'Ольга', 'Лебедева', 'Николаевна', 'Профессор', 'Кафедра программирования'),
('t3333333-3333-3333-3333-333333333333', 'Дмитрий', 'Кузнецов', 'Викторович', 'Зав. кафедрой', 'Кафедра информационных систем')
ON CONFLICT DO NOTHING;

-- ==========================================
-- 6. ГЭК и члены
-- ==========================================
INSERT INTO gek (id, name) VALUES
('k1111111-1111-1111-1111-111111111111', 'ГЭК-2026-ПИ')
ON CONFLICT DO NOTHING;

INSERT INTO gek_member (id, user_id, academic_title, department) VALUES
('m1111111-1111-1111-1111-111111111111', 'u0000000-0000-0000-0000-000000000009', 'Профессор, д.т.н.', 'Кафедра программирования'),
('m2222222-2222-2222-2222-222222222222', 'u0000000-0000-0000-0000-000000000010', 'Доцент, к.т.н.', 'Кафедра информационных систем')
ON CONFLICT DO NOTHING;

INSERT INTO gek_membership (id, gek_id, gek_member_id, position_in_gek) VALUES
('gm111111-1111-1111-1111-111111111111', 'k1111111-1111-1111-1111-111111111111', 'm1111111-1111-1111-1111-111111111111', 'CHAIRMAN'),
('gm222222-2222-2222-2222-222222222222', 'k1111111-1111-1111-1111-111111111111', 'm2222222-2222-2222-2222-222222222222', 'MEMBER')
ON CONFLICT DO NOTHING;

-- ==========================================
-- 7. Допуски к ГИА
-- ==========================================
INSERT INTO admission (id, student_id, brs_score, has_debt, is_admitted, checked_at) VALUES
('a1111111-1111-1111-1111-111111111111', 's1111111-1111-1111-1111-111111111111', 85, false, true, CURRENT_TIMESTAMP),
('a2222222-2222-2222-2222-222222222222', 's2222222-2222-2222-2222-222222222222', 78, false, true, CURRENT_TIMESTAMP),
('a3333333-3333-3333-3333-333333333333', 's3333333-3333-3333-3333-333333333333', 92, false, true, CURRENT_TIMESTAMP),
('a4444444-4444-4444-4444-444444444444', 's4444444-4444-4444-4444-444444444444', 65, true, false, CURRENT_TIMESTAMP)
ON CONFLICT DO NOTHING;

-- ==========================================
-- 8. Заседания ГЭК
-- ==========================================
INSERT INTO meeting (id, gek_id, meeting_date, location, status, quorum_required, created_by) VALUES
('mt111111-1111-1111-1111-111111111111', 'k1111111-1111-1111-1111-111111111111', '2026-06-15 10:00:00', 'Ауд. 305, корп. 1', 'PLANNED', 2, 'u0000000-0000-0000-0000-000000000008'),
('mt222222-2222-2222-2222-222222222222', 'k1111111-1111-1111-1111-111111111111', '2026-06-16 14:00:00', 'Ауд. 401, корп. 2', 'PLANNED', 2, 'u0000000-0000-0000-0000-000000000008')
ON CONFLICT DO NOTHING;

-- ==========================================
-- 9. Повестка заседаний
-- ==========================================
INSERT INTO agenda_item (id, meeting_id, student_id, order_number) VALUES
('ag111111-1111-1111-1111-111111111111', 'mt111111-1111-1111-1111-111111111111', 's1111111-1111-1111-1111-111111111111', 1),
('ag222222-2222-2222-2222-222222222222', 'mt111111-1111-1111-1111-111111111111', 's2222222-2222-2222-2222-222222222222', 2),
('ag333333-3333-3333-3333-333333333333', 'mt222222-2222-2222-2222-222222222222', 's3333333-3333-3333-3333-333333333333', 1)
ON CONFLICT DO NOTHING;

-- ==========================================
-- 10. Протоколы
-- ==========================================
INSERT INTO protocol (id, meeting_id, protocol_number, status) VALUES
('pr111111-1111-1111-1111-111111111111', 'mt111111-1111-1111-1111-111111111111', 'Пр-2026-001', 'DRAFT'),
('pr222222-2222-2222-2222-222222222222', 'mt222222-2222-2222-2222-222222222222', 'Пр-2026-002', 'DRAFT')
ON CONFLICT DO NOTHING;

-- ==========================================
-- 11. Задания (assignments)
-- ==========================================
INSERT INTO assignments (id, title, description, assignment_type, created_by, target_group_id, deadline, max_score, allow_late_submission) VALUES
('as111111-1111-1111-1111-111111111111', 'Разработка мобильного приложения', 'Создать приложение для автоматизации учета ГИА', 'COURSEWORK', 'u0000000-0000-0000-0000-000000000007', 'g1111111-1111-1111-1111-111111111111', '2026-06-10 23:59:59', 100, true),
('as222222-2222-2222-2222-222222222222', 'Написание отчета по практике', 'Подготовить отчет о прохождении производственной практики', 'PRACTICE_REPORT', 'u0000000-0000-0000-0000-000000000007', 'g2222222-2222-2222-2222-222222222222', '2026-06-15 23:59:59', 100, false)
ON CONFLICT DO NOTHING;

-- ==========================================
-- 12. Дисциплины
-- ==========================================
INSERT INTO discipline (id, name, code, department, credits, hours) VALUES
('di111111-1111-1111-1111-111111111111', 'Разработка мобильных приложений', 'РМП-101', 'Кафедра информационных систем', 5, 180),
('di222222-2222-2222-2222-222222222222', 'Базы данных', 'БД-201', 'Кафедра программирования', 4, 144),
('di333333-3333-3333-3333-333333333333', 'Программная инженерия', 'ПИН-301', 'Кафедра программирования', 6, 216)
ON CONFLICT DO NOTHING;

-- ==========================================
-- 13. Уведомления
-- ==========================================
INSERT INTO notification (id, user_id, title, message, is_read, created_at) VALUES
('n1111111-1111-1111-1111-111111111111', 'u0000000-0000-0000-0000-000000000012', 'Новое задание', 'Вам назначено задание "Разработка мобильного приложения"', false, CURRENT_TIMESTAMP),
('n2222222-2222-2222-2222-222222222222', 'u0000000-0000-0000-0000-000000000013', 'Допуск к ГИА', 'Вы допущены к государственной итоговой аттестации', false, CURRENT_TIMESTAMP)
ON CONFLICT DO NOTHING;
