# GIA_Mobile Патч — Инструкция по применению

## Что включено

### 1. SQL-миграции (backend/src/main/resources/db/migration/)
- **V34__demo_data_full.sql** — полноценные пробные данные для всех модулей и ролей с тестовыми учётными записями
- **V35__shared_drive.sql** — таблицы общего диска (`file_storage`, `file_folder`, `file_folder_item`)
- **V36__document_routing.sql** — документооборот: маршруты, этапы, шаблоны маршрутов, уведомления

### 2. Backend (Java)
- `FileStorage.java` — сущность файла в общем диске
- `FileStorageRepository.java` — JPA-репозиторий
- `FileStorageController.java` — REST API: загрузка, скачивание, список, удаление

### 3. Frontend (React + TypeScript)
- `useToastStore.ts` — глобальное хранилище toast-уведомлений с автоудалением
- `DragDropZone.tsx` — компонент Drag & Drop для загрузки файлов
- `files.ts` — API-клиент для работы с файлами

### 4. Промт для KimiCode
- `PROMPT_KIMICODE_MOBILE_APP.md` — готовый промт для создания APK студенческого портала

## Тестовые учётные записи (пароль: `password`)

| Логин | Роль | Портал |
|-------|------|--------|
| `admin` | Системный администратор | Администрация |
| `univ_admin` | Университетский администратор | Администрация |
| `dean` | Декан | Деканат |
| `dean_sec` | Секретарь деканата | Деканат |
| `dep_head` | Заведующий кафедрой | Кафедра |
| `dep_sec` | Секретарь кафедры | Кафедра |
| `supervisor` | Руководитель ВКР | Преподаватель |
| `gek_sec` | Секретарь ГЭК | Комиссия ГИА |
| `gek_chair` | Председатель ГЭК | Комиссия ГИА |
| `gek_member` | Член ГЭК | Комиссия ГИА |
| `methodist` | Методист | Методист |
| `student1` | Студент (ПИ-101) | Студент |
| `student2` | Студент (ПИ-101) | Студент |
| `student3` | Студент (ПИ-102) | Студент |
| `student4` | Студент (ПИ-102) | Студент |

## Как применить

### Способ 1: Через Git (рекомендуется)
1. Скопируй файлы из `backend/src/main/resources/db/migration/` в `backend/src/main/resources/db/migration/` своего проекта
2. Скопируй Java-файлы в соответствующие пакеты
3. Скопируй frontend-файлы в `frontend-web/src/`
4. Запусти `mvnw flyway:migrate` (или при старте Spring Boot миграции применятся автоматически)
5. Собери фронтенд: `npm run build`

### Способ 2: Ручное применение
1. Выполни SQL-файлы вручную в PostgreSQL (по порядку V34 → V35 → V36)
2. Добавь Java-классы в проект
3. Добавь frontend-компоненты

### Способ 3: Через GitHub API
Если нужно — могу закоммитить напрямую в репозиторий Walera96/GiaMobil1 через Pull Request.

## Что нужно сделать вручную (не включено в патч)

### Интеграция Toast-уведомлений
Добавь в `App.tsx` (или в `AppLayout.tsx`):
```tsx
import { ToastContainer } from './components/ui/Toast';
import { useToastStore } from './hooks/useToastStore';

function App() {
  const { toasts, removeToast } = useToastStore();
  return (
    <>
      <ToastContainer toasts={toasts} onRemove={removeToast} />
      {/* ... остальной рендер */}
    </>
  );
}
```

Использование:
```tsx
import { toast } from './hooks/useToastStore';

toast.success('Задание создано');
toast.error('Ошибка сохранения');
```

### Интеграция Drag & Drop в формы заданий
В компоненте создания/редактирования задания:
```tsx
import { DragDropZone } from './components/ui/DragDropZone';
import { filesApi } from './api/files';

const [files, setFiles] = useState<File[]>([]);

const handleDrop = async (droppedFiles: File[]) => {
  setFiles(prev => [...prev, ...droppedFiles]);
  for (const file of droppedFiles) {
    await filesApi.upload({ file, contextType: 'ASSIGNMENT', contextId: assignmentId });
  }
  toast.success('Файлы загружены');
};

<DragDropZone onFilesDrop={handleDrop} existingFiles={files} />
```

### Убрать англицизмы в URL (опционально)
Если нужно полностью убрать английские слова из URL:
- `/admin` → `/администрация`
- `/deanery` → `/деканат`
- `/teacher` → `/преподаватель`
- `/student-portal` → `/студент`

**Важно:** это требует обновления роутинга в React Router и всех ссылок.

## Шаблоны документооборота (V36)

После применения миграции V36 будут доступны 4 предустановленных шаблона маршрутов:
1. **Деканат → ГЭК** — согласование → передача → регистрация
2. **Кафедра → Деканат** — отчёты кафедры в деканат
3. **ГЭК → Бухгалтерия** — подписанные протоколы для начисления стипендии
4. **Деканат → Администрация** — приказы и распоряжения

## Низкий приоритет (потом)
- Слайдер баллов 0–100 (замена input type=number на `<input type="range">`)
- Аватарки с инициалами (если нет фото — первая буква фамилии)
- Цветные бейджи статусов (уже есть в Badge.tsx, нужно только применить)
- Карточки вместо таблиц — уже сделано

## Проверка после применения
1. Сборка backend: `./mvnw clean compile` → BUILD SUCCESS
2. Сборка frontend: `npm run build` → 0 errors
3. Запуск: `./mvnw spring-boot:run`
4. Вход под `student1` / `password` — проверка данных
5. Загрузка файла через Drag & Drop — проверка таблицы `file_storage`
6. Создание маршрута документа — проверка `document_route`

## Промт для KimiCode
Скопируй файл `PROMPT_KIMICODE_MOBILE_APP.md` и отправь в KimiCode для генерации мобильного приложения (APK). Он должен создать React Native + Expo проект, который можно собрать в APK через EAS Build.

## Вопросы?
Если что-то не собирается — присылай логи. Я поправлю. 🖤
